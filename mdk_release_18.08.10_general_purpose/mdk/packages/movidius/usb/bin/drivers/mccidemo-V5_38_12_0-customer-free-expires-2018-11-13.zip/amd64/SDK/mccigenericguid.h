/* mccigenericguid.h	Wed Jan 31 2007 05:00:00 drep */
/*

Module:  mccigenericguid.h

Function:
	The GUID for the MCCI generic driver.

Version:
	V4.39f	Wed Jan 31 2007 05:00:00 drep	Edit level 2

Copyright notice:
	This file copyright (C) 2000, 2007 by

		MCCI Corporation
		3520 Krums Corners Road
		Ithaca, NY  14850

	An unpublished work.  All rights reserved.
	
	This file is proprietary information, and may not be disclosed or
	copied without the prior permission of MCCI Corporation.
 
Author:
	Terry Moore, MCCI Corporation	April 2000

Revision history:
   3.12u  Fri Apr 28 2000 10:23:01  tmm
	Module created.

   4.39f  Wed Jan 31 2007 5:00:00 drep
	Automatic replacement of original company name and copyright strings.

*/

/* according to hoyle, this must be outside the #ifndefs */

/*
|| MCCI_GENERIC_DRIVER_INTERFACE_GUID identifies instances of the generic
|| driver.
*/
DEFINE_GUID(MCCI_GENERIC_DRIVER_INTERFACE_GUID,
        0x2236cc36, 0x1d11, 0x11d4, 0x81, 0x96, 0x00, 0x00, 0x86, 0x3b, 0x02, 0x30
        );

/* 
|| nothing goes in the below, but we include it to remind us that it should
|| be empty!!
*/
#ifndef _MCCIGENERICGUID_H_		/* prevent multiple includes */
#define _MCCIGENERICGUID_H_


/**** end of mccigenericguid.h ****/
#endif /* _MCCIGENERICGUID_H_ */
