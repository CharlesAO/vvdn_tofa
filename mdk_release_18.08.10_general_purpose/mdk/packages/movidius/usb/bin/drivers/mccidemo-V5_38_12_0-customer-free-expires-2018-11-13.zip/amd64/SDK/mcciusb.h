/* mcciusb.h	Thu Feb  4 2016 23:28:07 tmm */
/*

Module:  mcciusb.h

Function:
	Definitions for the MCCI generic USB driver library.

Version:
	V5.39g	Thu Feb  4 2016 23:28:07 tmm	Edit level 31

Copyright notice:
	This file copyright (C) 1997, 2000, 2003, 2007-2008, 2011-2013, 2016 by

		MCCI Corporation
		3520 Krums Corners Road
		Ithaca, NY  14850

	An unpublished work.  All rights reserved.

	This file is proprietary information, and may not be disclosed or
	copied without the prior permission of MCCI Corporation.

	Portions copyright (c) 1993, 2007 Microsoft Corporation.

Author:
	Terry Moore, MCCI Corporation	February 1997

Revision history:
   1.00a  Sun Feb  9 1997 22:31:41  tmm
	Module created.

   2.00a  3/2/97  tmm
	Add additional power-management things.

   2.10a  9/27/1997 tmm
	Add general USB device control operation.

   2.301  10/12/1997  tmm
	Removed ref to publish.h, as it is not needed for the
	generic code.

  2.53a  9/28/1998 johnk
	Added Cycle Port IOCtl.

  3.00e  12/9/1998 johnk
	Added Ioctl for ISOCH reads

  3.00h  1/26/1999 tmm
	Add IOCTL for controlling pipe timeout.

  3.00m  2/12/1999  tmm
	Fix typo in GET_VERSION definition.  Addd definitions for more
	IOCTLs:  GET_REMOVED_UNIT_MAP to get a bitmap of units that have
	been removed, ABORT_PIPE (to kill all pending I/Os on a pipe) and
	RESET_PIPE (wihch does a USBD reset-pipe operation).  ABORT_PIPE and
	RESET_PIPE on the device handle affect the control pipe.

   3.17a  Fri Dec  1 2000 15:12:45 sgs
	Add 2 new IOCTL's.
	MCCIUSB_CYCLE_PORT_GIVEN_DEVICE_NODE_IOCTL and
	MCCIUSB_CYCLE_PORT_GIVEN_DEVICE_NAME_IOCTL.

   3.49a  7/3/2003  tmm
	1097:  fix docs on direction bit

   4.37p  Mon Oct 02 2006 03:51:00  drep
	Added IOCTL_TEST_VECTOR_EXTRACTION and IOCTL_TEST_COVERAGE_VECTOR to 
	allow extraction from mcciusb corelib.

   4.39f  Wed Jan 31 2007 5:00:00 drep
	Automatic replacement of original company name and copyright strings.

   4.39m  Tue Apr 03 2007 12:00:17 saravanan
	PatchNum has been added to
	MCCIUSB_DRIVER_VERSION_RESULT

   4.39p  Wed Apr 11 2007 15:48:12 saravanan
   	Added macro ENCLOSE_QUOTE.

   4.49a4 Thu Oct 2 2008 12:20:00 drepich
	Bug 3785
	Fixed IOCTL_GET_SIZE to be coding style conformant 
	(MCCIUSB_IOCTL_GET_SIZE) including other semantic project IOCTLs that 
	were put in by former employee Supriya Ker.

   5.25d Wed Oct 13 2010 11:59:00 lucaslin
   	11209: Add USB3 Bus Interface IOCTL

   5.29a Tue Feb 8 2011 15:20:23 saravanan
   	12488:
   	Added support for new IOCTL MCCIUSB_WRITE_ZLP.

   5.29b Tue Mar 01 2011 17:55:31 nmkraj
	12388: Added Get Current Frame Number IOCTL

   5.29g  Tue Aug 24 2011 09:25:20  gobinath
	WHD-13638: Updated the IOCTLs MCCIUSB_GET_INTERFACE_INFO_IOCTL and
	MCCIUSB_GET_FULL_INTERFACE_INFO_IOCTL to cater the execution of 
	32 bit application using 64 bit driver

   5.29j  Mon Oct 31 2011 11:08:13  muthukrishnan
	WHD-14212:
	Added support for new IOCTL (MCCIUSB_IOCTL_SS_ENABLE and
	MCCIUSB_IOCTL_SS_DISABLE) for enable and disable selective suspend.

   5.31a Wed Dec 14 2011 09:56:23 saravanan
   	14530:
   	Added new IOCTLs
   	- MCCIUSB_IOCTL_REMOTE_WAKEUP_ENABLE
   	- MCCIUSB_IOCTL_REMOTE_WAKEUP_DISABLE
   	
   5.31a  Mon May 21 2012 11:45:23 gobinath
	15352: 
	Added the macros for displaying the configuration, interface
	and endpoint descriptors.

   5.31k  Wed Dec 04 2013 14:55:00 sanjay
	17863: Added following macros to validate IOCTL params
	- MCCIUSB_IOCTL_CHECK_GET_IOCTL_PARAM
	- MCCIUSB_IOCTL_CHECK_SET_IOCTL_PARAM
	- MCCIUSB_IOCTL_CHECK_GET_N_SET_IOCTL_PARAM

   5.39g  Mon Feb  1 2016 20:52:33  tmm
	19882: add MCCIUSB_IOCTL_GET_FULL_DEVICE_INFO

   5.39g  Thu Feb  4 2016 23:28:07  tmm
	19882: fix typo in name of structure field "AlternateSettings[]".

*/

#ifndef _MCCIUSB_H_		/* prevent multiple includes */
#define _MCCIUSB_H_


#include <usbdi.h>

/**** parameters ****/
#ifndef __MCCIUSB_OLD_NAMES
# define __MCCIUSB_OLD_NAMES 1
#endif

/****************************************************************************\
|
|	INFORMATION available to all
|
\****************************************************************************/

#define NAME_MAX		256
#define MAX_INTERFACE		8

#define	MCCIUSB_LENOF(a)	(sizeof(a) / sizeof(a[0]))

/*
||IOCTL info 
*/
#define MCCIUSB_IOCTL_INDEX  0x800

/*
|| WHCK invokes IOCTLs with valid & invalid param values
|| Need to validate IOCTL params before proceeding further
*/
#define MCCIUSB_IOCTL_CHECK_GET_IOCTL_PARAM(OutBuffLen, pIOBuff)	\
 	((pIOBuff) == NULL || (OutBuffLen) == 0 			\
 		? STATUS_INVALID_PARAMETER 				\
		: STATUS_SUCCESS)

#define MCCIUSB_IOCTL_CHECK_SET_IOCTL_PARAM(InBuffLen, pIOBuff)		\
	((pIOBuff) == NULL || (InBuffLen) == 0 				\
		? STATUS_INVALID_PARAMETER 				\
		: STATUS_SUCCESS)

#define MCCIUSB_IOCTL_CHECK_GET_N_SET_IOCTL_PARAM(			\
		InBuffLen, OutBuffLen, pIOBuff				\
		)							\
 	((pIOBuff) == NULL || (InBuffLen) == 0  || (OutBuffLen) == 0	\
		? STATUS_INVALID_PARAMETER 				\
		: STATUS_SUCCESS)

/****************************************************************************\
|
|  MCCIUSB_GET_NUM_DEVICES_IOCTL:
|
|	Return the number of logical devices currently in use.
|
\****************************************************************************/


typedef struct __MCCIUSB_GET_NUM_DEVICES_IOCTL_RESULT
	{
	ULONG	ulNumDevices;		/* number of devices */
	} MCCIUSB_GET_NUM_DEVICES_IOCTL_RESULT,
	  *PMCCIUSB_GET_NUM_DEVICES_IOCTL_RESULT;

#define MCCIUSB_GET_NUM_DEVICES_IOCTL \
		CTL_CODE(FILE_DEVICE_UNKNOWN,	\
			 MCCIUSB_IOCTL_INDEX+0, \
			 METHOD_BUFFERED,	\
			 FILE_ANY_ACCESS)

/****************************************************************************\
|
|  MCCIUSB_GET_DEVICE_INFO_IOCTL
|
|	DEPRECATED.
|
\****************************************************************************/

#define MCCIUSB_GET_DEVICE_INFO_IOCTL \
		CTL_CODE(FILE_DEVICE_UNKNOWN,	\
			 MCCIUSB_IOCTL_INDEX+1, \
			 METHOD_BUFFERED,	\
			 FILE_ANY_ACCESS)

/****************************************************************************\
|
| MCCIUSB_GET_DEVICE_DESCRIPTOR_IOCTL
|	Return the device descriptor in the user's buffer.
|
\****************************************************************************/

#define MCCIUSB_GET_DEVICE_DESCRIPTOR_IOCTL \
		CTL_CODE(FILE_DEVICE_UNKNOWN,	\
			 MCCIUSB_IOCTL_INDEX+2,	\
			 METHOD_BUFFERED,	\
			 FILE_ANY_ACCESS)

/****************************************************************************\
|
| MCCIUSB_GET_CONFIG_DESCRIPTOR_IOCTL
|	Return the configuration descriptor for this device (config 0)
|	in the user's buffer.
|
\****************************************************************************/


#define MCCIUSB_GET_CONFIG_DESCRIPTOR_IOCTL \
		CTL_CODE(FILE_DEVICE_UNKNOWN,	\
			 MCCIUSB_IOCTL_INDEX+3,	\
			 METHOD_BUFFERED,	\
			 FILE_ANY_ACCESS)

/****************************************************************************\
|
| MCCIUSB_GET_USBD_VERSION_IOCTL
|	Return the USBDI version information structure in the user's buffer.
|
\****************************************************************************/

/**** return USBD_VERSION_INFORMATION in the buffer ****/
#define MCCIUSB_GET_USBD_VERSION_IOCTL \
		CTL_CODE(FILE_DEVICE_UNKNOWN,   \
			 MCCIUSB_IOCTL_INDEX+4, \
			 METHOD_BUFFERED,	\
			 FILE_ANY_ACCESS)

/****************************************************************************\
|
| MCCIUSB_GET_INTERFACE_INFO_IOCTL:
|	Get information about the active interfaces for this device, as a
|	vector of USBD_INTERFACE_INFORMATION structures.
|
\****************************************************************************/

#define MCCIUSB_GET_INTERFACE_INFO_IOCTL \
		CTL_CODE(FILE_DEVICE_UNKNOWN,	\
			 MCCIUSB_IOCTL_INDEX+5,	\
			 METHOD_BUFFERED,	\
			 FILE_ANY_ACCESS)

/*
|| indices 6-8 are reserved for backwards compatibility and shall never
|| be assigned.
*/

/****************************************************************************\
|
| MCCIUSB_SEND_USB_CONTROL_IOCTL
|	Send a command plus data to the device.
|
|	buffer points to the image of the command (first 8 bytes)
|	followed immediately by the data to be sent.  The buffer
|	is not modified.  The command image first byte (bit 7) must be
|	clear; we use the target information to automatically fill
|	in the interface or endpoint info based on the path used
|	when the handle was opened.
|
|	If the handle was opened as a device handle, the wValue/wIndex data
|	is used "literally".
|
\****************************************************************************/

#define	MCCIUSB_SEND_USB_CONTROL_IOCTL	\
		CTL_CODE(FILE_DEVICE_UNKNOWN,	\
			 MCCIUSB_IOCTL_INDEX+9,	\
			 METHOD_BUFFERED,	\
			 FILE_ANY_ACCESS)

/****************************************************************************\
|
| MCCIUSB_GET_USB_CONTROL_IOCTL
|	Send command packet, get reply from device
|
|	buffer must be 8+n bytes long, and points to the image
|	of the command.  The data from the device is read into the
|	buffer immediately following the command.
|
|	The command image first byte (bit 7) must be set.  The remainder of
|	the routing information from the first byte is used to automatically
|	fill in the interface or endpoint info based on the ifc/ep path given
|	when then handle was opened.
|
|	If the handle was opened as a device handle, the wValue/wIndex data
|	is used "literally".
|
\****************************************************************************/

#define	MCCIUSB_GET_USB_CONTROL_IOCTL		\
		CTL_CODE(FILE_DEVICE_UNKNOWN,	\
			 MCCIUSB_IOCTL_INDEX+0xA, \
			 METHOD_BUFFERED,	\
			 FILE_ANY_ACCESS)

/****************************************************************************\
|
| MCCIUSB_GET_DEVICE_STATE_IOCTL
|	Returns the state of the device associated with the open handle.
|	Returns an MCCIUSB_GET_DEVICE_STATE_RESULT structure.
|
\****************************************************************************/

#define	MCCIUSB_GET_DEVICE_STATE_IOCTL	\
		CTL_CODE(FILE_DEVICE_UNKNOWN,	\
			 MCCIUSB_IOCTL_INDEX+0xB, \
			 METHOD_BUFFERED,	\
			 FILE_ANY_ACCESS)

/* here is the result structure for MCCIUSB_GET_DEVICE_STATE_IOCTL */
typedef struct __MCCIUSB_GET_DEVICE_STATE_RESULT
	{
	ULONG	Size;			/* size of this structure in bytes */
	ULONG	Removed;		/* true if the device was removed */
	ULONG	Stopped;		/* true if the device is stopped */
	ULONG	LastCloseRemove;	/* true if shutdown-on-last-close
					|| is pending
					*/
	} MCCIUSB_GET_DEVICE_STATE_RESULT,
	  *PMCCIUSB_GET_DEVICE_STATE_RESULT;

/****************************************************************************\
|
| MCCIUSB_DRIVER_VERSION_IOCTL
|	Return an MCCIUSB_DRIVER_VERSION_RESULT structure, with info about
|	the MCCIUSB driver library, etc.
|
\****************************************************************************/

#define	MCCIUSB_DRIVER_VERSION_IOCTL	\
		CTL_CODE(FILE_DEVICE_UNKNOWN,	\
			 MCCIUSB_IOCTL_INDEX+0xC, \
			 METHOD_BUFFERED,	\
			 FILE_ANY_ACCESS)

/* size of the string fields */
#define	MCCIUSB_DRIVER_VERSION_NPRODNAME	32
#define	MCCIUSB_DRIVER_VERSION_NVERSION		16
#define	MCCIUSB_DRIVER_VERSION_NDATE		32
#define	MCCIUSB_DRIVER_VERSION_NCOPYRIGHT	80

typedef struct __MCCIUSB_DRIVER_VERSION_RESULT
	{
	ULONG	Size;			/* size of this structure in bytes */
	ULONG	BuildNum;		/* the build number */
	ULONG	PatchNum;		/* Patch number */
	WCHAR	ProductName[MCCIUSB_DRIVER_VERSION_NPRODNAME];
					/* the product name string */
	WCHAR	Version[MCCIUSB_DRIVER_VERSION_NVERSION];
					/* the driver version string */
	WCHAR	Date[MCCIUSB_DRIVER_VERSION_NDATE];
					/* build date (__DATE__ format) */
	WCHAR	Copyright[MCCIUSB_DRIVER_VERSION_NCOPYRIGHT];
					/* the driver copyright version */

	} MCCIUSB_DRIVER_VERSION_RESULT,
	  *PMCCIUSB_DRIVER_VERSION_RESULT;


/****************************************************************************\
|
| ENCLOSE_QUOTE
|	Add double quote to the argument
|
\****************************************************************************/

#define ENCLOSE_QUOTE_ORIG(arg) L ## #arg
#define ENCLOSE_QUOTE(arg) ENCLOSE_QUOTE_ORIG(arg)


/****************************************************************************\
|
| MCCIUSB_CYCLE_PORT_IOCTL
|	Simulate a disconnect/reconnect cycle.
|
\****************************************************************************/

#define	MCCIUSB_CYCLE_PORT_IOCTL	CTL_CODE(FILE_DEVICE_UNKNOWN,	\
					MCCIUSB_IOCTL_INDEX+0xD, \
					METHOD_BUFFERED,	\
					FILE_ANY_ACCESS)

/****************************************************************************\
|
| MCCIUSB_ISOCH_READ_IOCTL
|	Issue a structure Isochronous read to a pipe.
|
\****************************************************************************/

/* Isoch Read requests */
#define MCCIUSB_ISOCH_READ_IOCTL	CTL_CODE(FILE_DEVICE_UNKNOWN, \
					MCCIUSB_IOCTL_INDEX+0xE, \
					METHOD_BUFFERED,	\
					FILE_ANY_ACCESS)

/* The layout of the structure used for Isoch Reads */
typedef struct __MCCIUSB_ISOCH_READ_REQUEST
	{
	/*
	|| IN - If TRUE, start as soon as possible, If FALSE, use StartFrame
	*/
	BOOLEAN	StartAsap;

	/*
	|| IN  - frame to start on. ignored if StartAsap is TRUE.
	|| OUT - starting frame number.
	*/
	ULONG	StartFrame;

	/*
	|| IN - Number of "frame" packets in buffer and in IsoPacket array.
	*/
	ULONG	NumberOfPackets;

	/* OUT - Number of packets that completed with errors */
	ULONG	ErrorCount;

	/* IN - Offset from start of structure to start of data area */
	ULONG	BufferOffset;

	/* IN - size of data area */
	ULONG	BufferSize;

	/* OUT - status for each packet - var-length array  */
	USBD_ISO_PACKET_DESCRIPTOR IsoPacket[1];

	/* Data area starts here */
	} MCCIUSB_ISOCH_READ_REQUEST, *PMCCIUSB_ISOCH_READ_REQUEST;

/****************************************************************************\
|
| MCCIUSB_GET_FULL_INTERFACE_INFO_IOCTL:
|	Get information about ALL interfaces for this device, as a
|	vector of USBD_INTERFACE_INFORMATION structures.
|
\****************************************************************************/

#define MCCIUSB_GET_FULL_INTERFACE_INFO_IOCTL \
		CTL_CODE(FILE_DEVICE_UNKNOWN,	\
			 MCCIUSB_IOCTL_INDEX+0xF, \
			 METHOD_BUFFERED,	\
			 FILE_ANY_ACCESS)

/****************************************************************************\
|
| MCCIUSB_GET_TIMEOUT_IOCTL:
| MCCIUSB_SET_TIMEOUT_IOCTL:
|	Get/set timeout information for a specific pipe, or for the  control
|	pipe (if used on a device level handle).
|
\****************************************************************************/

#define MCCIUSB_GET_TIMEOUT_IOCTL \
		CTL_CODE(FILE_DEVICE_UNKNOWN,	\
			 MCCIUSB_IOCTL_INDEX+0x10, \
			 METHOD_BUFFERED,	\
			 FILE_ANY_ACCESS)

#define MCCIUSB_SET_TIMEOUT_IOCTL \
		CTL_CODE(FILE_DEVICE_UNKNOWN,	\
			 MCCIUSB_IOCTL_INDEX+0x11, \
			 METHOD_BUFFERED,	\
			 FILE_ANY_ACCESS)

typedef struct __MCCIUSB_TIMEOUT_IOCTL_ARGS
	{
	LARGE_INTEGER	Delay100ns;
	} MCCIUSB_TIMEOUT_IOCTL_ARGS, *PMCCIUSB_TIMEOUT_IOCTL_ARGS;

/****************************************************************************\
|
| MCCIUSB_GET_REMOVED_UNIT_BITMPAP_IOCTL
|	Return a bitmap of units that have been removed, but which are
|	hanging around until the last close.   Note that some of the
|	unit numbers might already have been reused.  Bitmap is an array of
|	uchars, bit 0 is lsb, byte 0 is units 0..7, etc.
|
\****************************************************************************/

#define MCCIUSB_GET_REMOVED_UNIT_BITMAP_IOCTL \
		CTL_CODE(FILE_DEVICE_UNKNOWN,	\
			 MCCIUSB_IOCTL_INDEX+0x12, \
			 METHOD_BUFFERED,	\
			 FILE_ANY_ACCESS)

/****************************************************************************\
|
| MCCIUSB_GET_ACTIVE_UNIT_BITMAP_IOCTL
|	Return a bitmap of units that can be opened.  Because unit numbers are
|	agressively reused, this might have some overlap with the removed
|	units, if some units have not been closed and already have been
|	reused.
|
\****************************************************************************/

#define MCCIUSB_GET_ACTIVE_UNIT_BITMAP_IOCTL \
		CTL_CODE(FILE_DEVICE_UNKNOWN,	\
			 MCCIUSB_IOCTL_INDEX+0x13, \
			 METHOD_BUFFERED,	\
			 FILE_ANY_ACCESS)

/****************************************************************************\
|
| MCCIUSB_ABORT_PIPE_IOCTL:
|	Abort all pending I/O for a given pipe.  No argument.  If issued
|	to a device-level handle, aborts the control pipe.
|
\****************************************************************************/

#define MCCIUSB_ABORT_PIPE_IOCTL \
		CTL_CODE(FILE_DEVICE_UNKNOWN,	\
			 MCCIUSB_IOCTL_INDEX+0x14, \
			 METHOD_BUFFERED,	\
			 FILE_ANY_ACCESS)

/****************************************************************************\
|
| MCCIUSB_RESET_PIPE_IOCTL:
|	Issues a reset-pipe operation to USBD, which clears out stall
|	conditions and so forth.  No argument.  If issed on the device-level
|	handle, the control pipe gets reset.
|
\****************************************************************************/

#define MCCIUSB_RESET_PIPE_IOCTL \
		CTL_CODE(FILE_DEVICE_UNKNOWN,	\
			 MCCIUSB_IOCTL_INDEX+0x15, \
			 METHOD_BUFFERED,	\
			 FILE_ANY_ACCESS)

/****************************************************************************\
|
| MCCIUSB_UNSTALL_PIPE_IOCTL:
|	Issues an unstall-pipe operation to MCCI's USB lib, which clears
|	the endpoint-stall feature on the associated endpoint, and also
|	(for non-control endpoints) resets the USBD "halted" flag.
|
\****************************************************************************/

#define MCCIUSB_UNSTALL_PIPE_IOCTL \
		CTL_CODE(FILE_DEVICE_UNKNOWN,	\
			 MCCIUSB_IOCTL_INDEX+0x16, \
			 METHOD_BUFFERED,	\
			 FILE_ANY_ACCESS)

/****************************************************************************\
|
| MCCIUSB_CYCLE_PORT_GIVEN_DEVICE_NODE_IOCTL
|	Find the PDO given the devnode then
|	Simulate a disconnect/reconnect cycle.
|
\****************************************************************************/

#define	MCCIUSB_CYCLE_PORT_GIVEN_DEVICE_NODE_IOCTL	\
		CTL_CODE(FILE_DEVICE_UNKNOWN,	\
			MCCIUSB_IOCTL_INDEX+0x17, \
			METHOD_BUFFERED,	\
			FILE_ANY_ACCESS)

/****************************************************************************\
|
| MCCIUSB_CYCLE_PORT_GIVEN_DEVICE_NAME_IOCTL
|	Find the PDO given the device unicode name then
|	Simulate a disconnect/reconnect cycle.
|
\****************************************************************************/

#define	MCCIUSB_CYCLE_PORT_GIVEN_DEVICE_NAME_IOCTL	\
		CTL_CODE(FILE_DEVICE_UNKNOWN,	\
			MCCIUSB_IOCTL_INDEX+0x18, \
			METHOD_BUFFERED,	\
			FILE_ANY_ACCESS)

#define	MCCIUSB_IOCTL_GET_SIZE	\
		CTL_CODE(FILE_DEVICE_UNKNOWN,	\
			MCCIUSB_IOCTL_INDEX+0x19, \
			METHOD_BUFFERED,	\
			FILE_ANY_ACCESS)


#define	MCCIUSB_IOCTL_TEST_VECTOR_EXTRACTION	\
		CTL_CODE(FILE_DEVICE_UNKNOWN,	\
			MCCIUSB_IOCTL_INDEX+0x1A, \
			METHOD_BUFFERED,	\
			FILE_ANY_ACCESS)


#define	MCCIUSB_IOCTL_TEST_COVERAGE_VECTOR	\
		CTL_CODE(FILE_DEVICE_UNKNOWN,	\
			MCCIUSB_IOCTL_DEVSPEC_INDEX+0x1B, \
			METHOD_BUFFERED,	\
			FILE_ANY_ACCESS)


/****************************************************************************\
|
| MCCIUSB_IOCTL_USB3_BUSIFC_GET_ABSTRACT_INTERFACE
|	Get USB3 bus interface information.
|
| MCCIUSB_IOCTL_USB3_BUSIFC_PUT_ABSTRACT_INTERFACE
|	Free all resources allocated from the USB3 bus interface if any.
|
\****************************************************************************/

#define	MCCIUSB_IOCTL_USB3_BUSIFC_GET_ABSTRACT_INTERFACE		\
		CTL_CODE(FILE_DEVICE_UNKNOWN,				\
			MCCIUSB_IOCTL_DEVSPEC_INDEX+0x1C, 		\
			METHOD_BUFFERED,				\
			FILE_ANY_ACCESS)

#define	MCCIUSB_IOCTL_USB3_BUSIFC_PUT_ABSTRACT_INTERFACE		\
		CTL_CODE(FILE_DEVICE_UNKNOWN,				\
			MCCIUSB_IOCTL_DEVSPEC_INDEX+0x1D, 		\
			METHOD_BUFFERED,				\
			FILE_ANY_ACCESS)

typedef struct __MCCIUSB_USB3_BUSIFC_ABSTRACT_INTERFACE
	{
	USHORT		Size;
	USHORT		Version;
	} MCCIUSB_USB3_BUSIFC_ABSTRACT_INTERFACE,
	  *PMCCIUSB_USB3_BUSIFC_ABSTRACT_INTERFACE;


/****************************************************************************\
|
| MCCIUSB_IOCTL_USB3_BUSIFC_EXECUTE_REQUEST
|	Execute a USBD3 abstract bus interface function described in
|	4.3 of 	http://www.mcci.com/mcci-v5/pdf/950001001b.pdf
\****************************************************************************/
#define	MCCIUSB_IOCTL_USB3_BUSIFC_EXECUTE_REQUEST			\
		CTL_CODE(FILE_DEVICE_UNKNOWN,				\
			MCCIUSB_IOCTL_DEVSPEC_INDEX+0x1E, 		\
			METHOD_BUFFERED,				\
			FILE_ANY_ACCESS)

typedef	struct __MCCIUSB_USB3_BUSIFC_REQUEST_BLOCK
	{
	IN	ULONG		Function;
	IN	PVOID		Param1;
	IN	PVOID		Param2;
	IN	PVOID		Param3;
	IN	PVOID		Param4;
	IN	PVOID		UserBuffer;
	IN 	ULONG		UserBufferInputLength;
	OUT	ULONG		UserBufferOutputLength;

	IN OUT	ULONG		ulParam1;
	IN OUT	ULONG		ulParam2;

	OUT	LONG		IoStatus;
	OUT	LONG		usbStatus;

	} MCCIUSB_USB3_BUSIFC_REQUEST_BLOCK,
	*PMCCIUSB_USB3_BUSIFC_REQUEST_BLOCK;

typedef enum __MCCIUSB_USB3_BUSIFC_FUNCTION {
	MCCIUSB_USB3_BUSIFC_FN_PREPARE_SELECT_CONFIGURATION,		/* 4.3.1	*/
	MCCIUSB_USB3_BUSIFC_FN_PREPARE_SELECT_INTERFACE,		/* 4.3.2	*/

	MCCIUSB_USB3_BUSIFC_FN_CFGREQ_GET_CONFIG_HANDLE,		/* 4.3.3	*/
	MCCIUSB_USB3_BUSIFC_FN_CFGREQ_GET_HIFC_INFO,			/* 4.3.4	*/
	MCCIUSB_USB3_BUSIFC_FN_CFGREQ_GET_HIFC_INFO_COUNT,		/* 4.3.5	*/
	MCCIUSB_USB3_BUSIFC_FN_CFGREQ_SUBMIT,				/* 4.3.6	*/
	MCCIUSB_USB3_BUSIFC_FN_CFGREQ_REFERENCE,			/* 4.3.7	*/
	MCCIUSB_USB3_BUSIFC_FN_CFGREQ_CLOSE,				/* 4.3.8	*/

	MCCIUSB_USB3_BUSIFC_FN_IFCREQ_SUBMIT,				/* 4.3.9	*/
	MCCIUSB_USB3_BUSIFC_FN_IFCREQ_GET_HIFC_INFO,			/* 4.3.10	*/
	MCCIUSB_USB3_BUSIFC_FN_IFCREQ_REFERENCE,			/* 4.3.11	*/
	MCCIUSB_USB3_BUSIFC_FN_IFCREQ_CLOSE,				/* 4.3.12	*/

	MCCIUSB_USB3_BUSIFC_FN_IFCINFO_GET_INTERFACE_INFORMATION,	/* 4.3.13	*/
	MCCIUSB_USB3_BUSIFC_FN_IFCINFO_SET_INTERFACE_INFORMATION,	/* 4.3.14	*/
	MCCIUSB_USB3_BUSIFC_FN_IFCINFO_GET_HPIPE_INFO,			/* 4.3.15	*/
	MCCIUSB_USB3_BUSIFC_FN_IFCINFO_REFERENCE,			/* 4.3.16	*/
	MCCIUSB_USB3_BUSIFC_FN_IFCINFO_CLOSE,				/* 4.3.17	*/

	MCCIUSB_USB3_BUSIFC_FN_PIPEINFO_OPEN_STREAM,			/* 4.3.18	*/
	MCCIUSB_USB3_BUSIFC_FN_PIPEINFO_GET_USBD3_PIPE_INFORMATION,	/* 4.3.19	*/
	MCCIUSB_USB3_BUSIFC_FN_PIPEINFO_SET_USBD3_PIPE_INFORMATION,	/* 4.3.20	*/
	MCCIUSB_USB3_BUSIFC_FN_PIPEINFO_REFERENCE,			/* 4.3.21	*/
	MCCIUSB_USB3_BUSIFC_FN_PIPEINFO_CLOSE,				/* 4.3.22	*/

	MCCIUSB_USB3_BUSIFC_FN_STREAM_PREPARE_REQUEST,			/* 4.3.23	*/
	MCCIUSB_USB3_BUSIFC_FN_STREAM_REFERENCE,			/* 4.3.24	*/
	MCCIUSB_USB3_BUSIFC_FN_STREAM_CLOSE,				/* 4.3.25	*/

	MCCIUSB_USB3_BUSIFC_FN_STREAMREQ_SUBMIT,			/* 4.3.26	*/
	MCCIUSB_USB3_BUSIFC_FN_STREAMREQ_CANCEL,			/* 4.3.27	*/
	MCCIUSB_USB3_BUSIFC_FN_STREAMREQ_REFERENCE,			/* 4.3.28	*/
	MCCIUSB_USB3_BUSIFC_FN_STREAMREQ_CLOSE,				/* 4.3.29	*/

	MCCIUSB_USB3_BUSIFC_FN_GET_DEVICE_OPERATING_SPEED,		/* 4.3.30	*/
	MCCIUSB_USB3_BUSIFC_FN_GET_PROVIDER_INFO,			/* 4.3.31	*/

	MCCIUSB_USB3_BUSIFC_FN_PIPE_REQUEST_SUBMIT

	} MCCIUSB_USB3_BUSIFC_FUNCTION, *PMCCIUSB_USB3_BUSIFC_FUNCTION;

/*
| Request:	MCCIUSB_USB3_BUSIFC_FN_PREPARE_SELECT_CONFIGURATION
|
| Function:
|	This function gets ConfigurationDescriptors as pointed by UserBuffer
|	parameter, and calls PrepareSelectConfiguration(). Upon successful
|	return of PrepareSelectConfiguration(), the kernel mode generic driver
|	updates Param1 parameter with the returned hCfgRequest from
|	PrepareSelectConfiguration().
|	When hCfgRequest is not in use, user mode application should close
|	it with MCCIUSB_USB3_BUSIFC_FN_CFGREQ_CLOSE.
|
| Parameters:
|	IN UserBuffer:
|	A caller supplied pointer to Configuration Descriptors. User mode application
|	retrieves Configurations Descriptors by MCCIUSB_GET_CONFIG_DESCRIPTOR_IOCTL.
|
|	IN UserBufferInputLength: Length of UserBuffer
|
|	OUT Param1: hCfgRequest returned from PrepareSelectConfiguration().
|
| Reference:	4.3.1 of 950001001b.pdf
|
*/


/*
| Request:	MCCIUSB_USB3_BUSIFC_FN_PREPARE_SELECT_INTERFACE
|
| Function:
|	This function prepare a "USB3-aware" select-interface request by
|	calling PrepareSelectInterface(). Caller should pass hCfgRequest
|	returned from MCCIUSB_USB3_BUSIFC_FN_PREPARE_SELECT_CONFIGURATION
|	in Param1, iInterface in Param2 paramter, iAltSetting in Param3.
|	Upon successful return of PrepareSelectInterface, kernel mode driver
|	updates hIfcRequest in Param4.
|
|	If hIfcRequest is not in use, caller should close it with
|	MCCIUSB_USB3_BUSIFC_FN_IFCREQ_CLOSE.
|
| Parameters:
|	IN Param1: hCfgRequest returned from MCCIUSB_USB3_BUSIFC_FN_PREPARE_SELECT_CONFIGURATION.
|
|	IN ulParam1: iInterface value.
|
|	IN ulParam2: iAltSetting value.
|
|	OUT Param2: hIfcRequest returned from PrepareSelectInterface().
|
| Reference:	4.3.2 of 950001001b.pdf
|
*/

/*
| Request:	MCCIUSB_USB3_BUSIFC_FN_CFGREQ_GET_CONFIG_HANDLE
|
| Function:
|	This function gets USBD_CONFIGURATION_HANDLE from the result of
|	a submitted SELECT_CONFIGURATION_ operation.
|
| Parameters:
|	IN Param1: hCfgRequest returned from MCCIUSB_USB3_BUSIFC_FN_PREPARE_SELECT_CONFIGURATION.
|
|	OUT Param2: hCfgHanlde
|		Type : USBD_CONFIGURATION_HANDLE.
|
| Reference:	4.3.3 of 950001001b.pdf
|
*/


/*
| Request:	MCCIUSB_USB3_BUSIFC_FN_CFGREQ_GET_HIFC_INFO
|
| Function:
|	This function returns the "interface information" handle for a specific
|	interface instance.
|
| Parameters:
|	IN Param1: hCfgRequest returned from MCCIUSB_USB3_BUSIFC_FN_PREPARE_SELECT_CONFIGURATION.
|
|	IN Param2: iInterface
|
|	OUT Param3: interface information handle
|		Type: MCCIUSBD_USBD3_HIFCINFO
|
| Reference:	4.3.4 of 950001001b.pdf
|
*/


/*
| Request:	MCCIUSB_USB3_BUSIFC_FN_CFGREQ_GET_HIFC_INFO_COUNT
|
| Function:
|	A wrapper for CfgRequest_GetHifcInfoCount.
|
| Parameters:
|	IN Param1: hCfgRequest returned from MCCIUSB_USB3_BUSIFC_FN_PREPARE_SELECT_CONFIGURATION.
|
|	OUT ulParam1: a ULONG value of number of interface information handle are
|		available for the specified request.
|
| Reference:	4.3.5 of 950001001b.pdf
|
*/

/*
| Request:	MCCIUSB_USB3_BUSIFC_FN_CFGREQ_SUBMIT
|
| Function:
|	A wrapper for CfgRequest_Submit. Submit a "USB3-aware" select
|	configuration request.
|	MCCI generic driver submit the request and return the ntStatus
|	immediately. If the ntStatus is STATUS_PENDING, generic driver does not
|	complete the IOCTL. Only after the request is completed from the
|	USB3 Bus interface will the generic driver complete the IOCTL.
|
| Parameters:
|	IN Param1: hCfgRequest returned from MCCIUSB_USB3_BUSIFC_FN_PREPARE_SELECT_CONFIGURATION.
|
|	OUT IoStatus: the ntStatus carried out by CfgRequest_Submit
|
| Reference:	4.3.6 of 950001001b.pdf
|
*/


/*
| Request:	MCCIUSB_USB3_BUSIFC_FN_CFGREQ_REFERENCE
|
| Function:
|	A wrapper for CfgRequest_Reference. Create an additional reference
|	to hCfgRequest.
|
| Parameters:
|	IN Param1: hCfgRequest returned from MCCIUSB_USB3_BUSIFC_FN_PREPARE_SELECT_CONFIGURATION.
|
| Reference:	4.3.7 of 950001001b.pdf
|
*/

/*
| Request:	MCCIUSB_USB3_BUSIFC_FN_CFGREQ_CLOSE
|
| Function:
|	A wrapper for CfgRequest_Close. Retract a reference to hCfgRequest.
|
| Parameters:
|	IN Param1: hCfgRequest returned from MCCIUSB_USB3_BUSIFC_FN_PREPARE_SELECT_CONFIGURATION.
|
| Reference:	4.3.8 of 950001001b.pdf
|
*/

/*
| Request:	MCCIUSB_USB3_BUSIFC_FN_IFCREQ_SUBMIT
|
| Function:
|	A wrapper for IfcRequest_Submit. Submit a "USB3-aware" select-interface
|	request.
|
| Parameters:
|	IN Param1: hIfcRequest returned from MCCIUSB_USB3_BUSIFC_FN_PREPARE_SELECT_INTERFACE.
|
|	OUT IoStatus: the ntStatus carried out by IfcRequest_Submit
|
| Reference:	4.3.9 of 950001001b.pdf
|
*/

/*
| Request:	MCCIUSB_USB3_BUSIFC_FN_IFCREQ_GET_HIFC_INFO
|
| Function:
|	A wrapper for IfcRequest_GetHIfcInfo. Return the "interface information"
|	handle for the interface being modified by SELECT-INTERFACE.
|	request.
|
| Parameters:
|	IN Param1: hIfcRequest returned from MCCIUSB_USB3_BUSIFC_FN_PREPARE_SELECT_INTERFACE.
|
|	OUT Param2:  hIfcInfo returned from IfcRequest_GetHIfcInfo().
|		Type: MCCIUSBD_USBD3_HIFCINFO
|
| Reference:	4.3.10 of 950001001b.pdf
|
*/

/*
| Request:	MCCIUSB_USB3_BUSIFC_FN_IFCREQ_REFERENCE
|
| Function:
|	A wrapper for IfcRequest_Reference. Create an additional reference
|	to hIfcRequest.
|
| Parameters:
|	IN Param1: hIfcRequest returned from MCCIUSB_USB3_BUSIFC_FN_PREPARE_SELECT_INTERFACE.
|
| Reference:	4.3.11 of 950001001b.pdf
|
*/

/*
| Request:	MCCIUSB_USB3_BUSIFC_FN_IFCREQ_CLOSE
|
| Function:
|	A wrapper for IfcRequest_Reference. Retract a reference
|	to hIfcRequest.
|
| Parameters:
|	IN Param1: hIfcRequest returned from MCCIUSB_USB3_BUSIFC_FN_PREPARE_SELECT_INTERFACE.
|
| Reference:	4.3.12 of 950001001b.pdf
|
*/

/*
| Request:	MCCIUSB_USB3_BUSIFC_FN_IFCINFO_GET_INTERFACE_INFORMATION
|
| Function:
|	A wrapper for IfcInfo_GetInterfaceInformation. Fetch interface information
|	from hIfcInfo
|
| Parameters:
|	IN Param1: hIfcInfo returned from MCCIUSB_USB3_BUSIFC_FN_IFCREQ_GET_HIFC_INFO.
|
|	OUT UserBuffer: User allocated buffer large enough to hold
|		MCCIUSB_USBD3_INTERFACE_INFORMATION structure
|
|	IN UserBufferInputLength:
|		The size of UserBuffer. Shall be at least sizeof(MCCIUSB_USBD3_INTERFACE_INFORMATION).
|
|	OUT UserBufferOutputLength:
|		On output, kernel mode driver set this field to sizeof
|		(MCCIUSB_USBD3_INTERFACE_INFORMATION) if operation is successful.
|		Otherwise, kernel mode driver sets this to 0.
|
| Reference:	4.3.13 of 950001001b.pdf
|
*/

/*
| Request:	MCCIUSB_USB3_BUSIFC_FN_IFCINFO_SET_INTERFACE_INFORMATION
|
| Function:
|	A wrapper for IfcInfo_SetInterfaceInformation. set interface information
|	to hIfcInfo
|
| Parameters:
|	IN Param1: hIfcInfo returned from MCCIUSB_USB3_BUSIFC_FN_IFCREQ_GET_HIFC_INFO.
|
|	OUT UserBuffer: User allocated buffer large enough to hold
|		MCCIUSB_USBD3_INTERFACE_INFORMATION structure
|
|	IN UserBufferInputLength:
|		The size of UserBuffer. Shall be at least sizeof(MCCIUSB_USBD3_INTERFACE_INFORMATION).
|
| Reference:	4.3.14 of 950001001b.pdf
|
*/

/*
| Request:	MCCIUSB_USB3_BUSIFC_FN_IFCINFO_GET_HPIPE_INFO
|
| Function:
|	A wrapper for IfcInfo_GetHPipeInfo. Get pipe information handle
|	for a specific pipe in hIfcInfo.
|
| Parameters:
|	IN Param1: hIfcInfo returned from MCCIUSB_USB3_BUSIFC_FN_IFCREQ_GET_HIFC_INFO.
|
|	IN ulParam1: iPipe value.
|
|	OUT Param3: hPipeInfo returned from IfcInfo_GetHPipeInfo
|
| Reference:	4.3.15 of 950001001b.pdf
|
*/

/*
| Request:	MCCIUSB_USB3_BUSIFC_FN_IFCINFO_REFERENCE
|
| Function:
|	A wrapper for IfcInfo_Reference. Add a reference to hIfcInfo.
|
| Parameters:
|	IN Param1: hIfcInfo returned from MCCIUSB_USB3_BUSIFC_FN_IFCREQ_GET_HIFC_INFO.
|
| Reference:	4.3.16 of 950001001b.pdf
|
*/

/*
| Request:	MCCIUSB_USB3_BUSIFC_FN_IFCINFO_CLOSE
|
| Function:
|	A wrapper for IfcInfo_Reference. Retract a reference to hIfcInfo.
|
| Parameters:
|	IN Param1: hIfcInfo returned from MCCIUSB_USB3_BUSIFC_FN_IFCREQ_GET_HIFC_INFO.
|
| Reference:	4.3.17 of 950001001b.pdf
|
*/

/*
| Request:	MCCIUSB_USB3_BUSIFC_FN_PIPEINFO_OPEN_STREAM
|
| Function:
|	A wrapper for PipeInfo_OpenStream.
|
| Parameters:
|	IN Param1: hPipeInfo returned from MCCIUSB_USB3_BUSIFC_FN_IFCINFO_GET_HPIPE_INFO.
|
|	IN ulParam1: idStream
|
|	OUT Param2: hStream, a stream handle
|
| Reference:	4.3.18 of 950001001b.pdf
|
*/

/*
| Request:	MCCIUSB_USB3_BUSIFC_FN_PIPEINFO_GET_USBD3_PIPE_INFORMATION
|
| Function:
|	A wrapper for PipeInfo_GetUsbd3PipeInformation.
|
| Parameters:
|	IN Param1: hPipeInfo returned from MCCIUSB_USB3_BUSIFC_FN_IFCINFO_GET_HPIPE_INFO.
|
|	IN UserBuffer: a user buffer large enough to hold MCCIUSBD_USBD3_PIPE_INFORMATION
|
|	IN UserBufferInputLength: at least sizeof(MCCIUSBD_USBD3_PIPE_INFORMATION)
|
|	OUT UserBufferOutputLength: If operation successful, the kernel driver
|		set this to sizeof(MCCIUSBD_USBD3_PIPE_INFORMATION). Otherwise
|		this field is set to 0.
|
| Reference:	4.3.19 of 950001001b.pdf
|
*/

/*
| Request:	MCCIUSB_USB3_BUSIFC_FN_PIPEINFO_SET_USBD3_PIPE_INFORMATION
|
| Function:
|	A wrapper for PipeInfo_setUsbd3PipeInformation.
|
| Parameters:
|	IN Param1: hPipeInfo returned from MCCIUSB_USB3_BUSIFC_FN_IFCINFO_GET_HPIPE_INFO.
|
|	IN UserBuffer: a user buffer large enough to hold MCCIUSBD_USBD3_PIPE_INFORMATION
|
|	IN UserBufferInputLength: at least sizeof(MCCIUSBD_USBD3_PIPE_INFORMATION)
|
| Reference:	4.3.20 of 950001001b.pdf
|
*/

/*
| Request:	MCCIUSB_USB3_BUSIFC_FN_PIPEINFO_REFERENCE
|
| Function:
|	A wrapper for PipeInfo_Reference
|
| Parameters:
|	IN Param1: hPipeInfo returned from MCCIUSB_USB3_BUSIFC_FN_IFCINFO_GET_HPIPE_INFO.
|
| Reference:	4.3.21 of 950001001b.pdf
|
*/

/*
| Request:	MCCIUSB_USB3_BUSIFC_FN_PIPEINFO_CLOSE
|
| Function:
|	A wrapper for PipeInfo_Close
|
| Parameters:
|	IN Param1: hPipeInfo returned from MCCIUSB_USB3_BUSIFC_FN_IFCINFO_GET_HPIPE_INFO.
|
| Reference:	4.3.22 of 950001001b.pdf
|
*/

/*
| Request:	MCCIUSB_USB3_BUSIFC_FN_STREAM_PREPARE_REQUEST
|
| Function:
|	A wrapper for Stream_PrepareRequest
|
| Parameters:
|	IN Param1: hStream returned from MCCIUSB_USB3_BUSIFC_FN_PIPEINFO_OPEN_STREAM.
|
|	IN UserBuffer: User buffer for the stream request.
|
|	IN UserBufferInputLength : the size of UserBuffer.
|
|	IN ulParam1: shall one of the following values:
|			MCCIUSB_TRANSFER_FLAGS_DIR_IN, or
|			MCCIUSB_TRANSFER_FLAGS_DIR_IN | MCCIUSB_TRANSFER_FLAGS_SHORT_OK, or
|			MCCIUSB_TRANSFER_FLAGS_DIR_OUT.
|
|	OUT Param2: hStreamRq. Kernel mode driver allocates an stream request context
|	to the user mode application. This is used later by StreamRequest_Submit,
|	StreamRequest_Cancel,StreamRequest_Reference, StreamRequest_Close.
|
|	Remarks:
|	Kernel mode driver allocates MDL for UserBuffer and locks down physical
|	pages assocated with UserBuffer. The MDL de-allocation and physical pages
|	unlock operation will only happen when user mode process triggers
|	MCCIUSB_USB3_BUSIFC_FN_STREAMREQ_CLOSE.
|
|	Caller must close the stream request handle by
|	MCCIUSB_USB3_BUSIFC_FN_STREAMREQ_CLOSE when the request is not needed.
|
| Reference:	4.3.23 of 950001001b.pdf
|
*/
#define	MCCIUSB_TRANSFER_FLAGS_DIR_MASK		(1 << 0)
#define	MCCIUSB_TRANSFER_FLAGS_DIR_OUT		(0 << 0)
#define	MCCIUSB_TRANSFER_FLAGS_DIR_IN		(1 << 0)

#define	MCCIUSB_TRANSFER_FLAGS_SHORT_OK		(1 << 1)

/*
| Request:	MCCIUSB_USB3_BUSIFC_FN_STREAM_REFERENCE
|
| Function:
|	A wrapper for Stream_Reference
|
| Parameters:
|	IN Param1: hStream returned from MCCIUSB_USB3_BUSIFC_FN_PIPEINFO_OPEN_STREAM.
|
|
| Reference:	4.3.24 of 950001001b.pdf
|
*/

/*
| Request:	MCCIUSB_USB3_BUSIFC_FN_STREAM_CLOSE
|
| Function:
|	A wrapper for Stream_Close
|
| Parameters:
|	IN Param1: hStream returned from MCCIUSB_USB3_BUSIFC_FN_PIPEINFO_OPEN_STREAM.
|
|
| Reference:	4.3.25 of 950001001b.pdf
|
*/

/*
| Request:	MCCIUSB_USB3_BUSIFC_FN_STREAMREQ_SUBMIT
|
| Function:
|	A wrapper for StreamRequest_Submit
|
| Parameters:
|	IN Param1: hStreamRq returned from MCCIUSB_USB3_BUSIFC_FN_STREAM_PREPARE_REQUEST.
|
| Remarks:
|	User mode application sends this IOCTL exercise a stream request previously
|	prepared by MCCIUSB_USB3_BUSIFC_FN_STREAM_PREPARE_REQUEST. Kernel mode driver
|	in turn triggers StreamRequest_Submit(). The kernel mode driver returns
|	CPU control to system immediately after StreamRequest_Submit() without
|	waiting for pDoneFn triggered by USB3 bus interface.
|
|	As such, the IRP associated with this IOCTL is not completed, and user mode
|	process will get stuck if lpOverLapped is not specified when triggering this
|	IOCTL. The IOCTL is completed after pDoneFn is triggered from USB3 bus
|	interface.
|
|	To allow asynchronous operation, user mode process shall specify
|	lpOverLapped structure when triggering DeviceIoControl
|	(http://msdn.microsoft.com/en-us/library/aa363216%28VS.85%29.aspx).
|
|	Upon completion of this IOCTL, kernel mode driver updates the following
|	fields:
|	IoStatus: This is essentially the ntStatus returned from pDoneFn.
|	UserBufferOutputLength : This is TransferBufferLength returned from pDoneFn.
|	usbStatus : This is usbStatus returned from pDoneFn.
|
| Reference:	4.1.2.3 & 4.3.26 of 950001001b.pdf
|
*/


/*
| Request:	MCCIUSB_USB3_BUSIFC_FN_STREAMREQ_CANCEL
|
| Function:
|	A wrapper for StreamRequest_Cancel
|
| Parameters:
|	IN Param1: hStreamRq returned from MCCIUSB_USB3_BUSIFC_FN_STREAM_PREPARE_REQUEST.
|
| Remarks:
|	User mode application sends this IOCTL cancel a previously submitted stream
|	request. A privously submitted stream request made by
|	MCCIUSB_USB3_BUSIFC_FN_STREAMREQ_SUBMIT will only be completed when
|	USB3 bus interface completes the request, or when this IOCTL is issued.
|
|	This IOCTL eventually causes previously submitted stream request
|	completed with STATUS_CANCELLED.
|
| Reference:	4.3.27 of 950001001b.pdf
|
*/

/*
| Request:	MCCIUSB_USB3_BUSIFC_FN_PIPE_REQUEST_SUBMIT
|
| Function:
|	Read/Write a user buffer from/to the pipe specified by PipeHandle
|
| Parameters:
|	IN Param1: PipeHandle in MCCIUSBD_USBD3_PIPE_INFORMATION.
|
|	IN UserBuffer: User buffer for the stream request.
|
|	IN UserBufferInputLength : the size of UserBuffer.
|
|	IN ulParam1: shall be one of the following values:
|			MCCIUSB_TRANSFER_FLAGS_DIR_IN, or
|			MCCIUSB_TRANSFER_FLAGS_DIR_IN | MCCIUSB_TRANSFER_FLAGS_SHORT_OK, or
|			MCCIUSB_TRANSFER_FLAGS_DIR_OUT.
|
|	OUT IoStatus: the ntStatus returned from the completion function of
|		bulk transfer.
|
|	OUT UserBufferOutputLength: the actual trasfer size completed by the
|		USBD interface
|
|	Remarks:
|	Kernel mode driver allocates MDL for UserBuffer and locks down physical
|	pages assocated with UserBuffer. The MDL de-allocation and physical pages
|	unlock operation will only happen when this IOCTL is completed.
|
*/


/****************************************************************************\
|
| MCCIUSB_IOCTL_WRITE_ZLP:
|	Send a 0 length packet.
|
\****************************************************************************/

#define MCCIUSB_IOCTL_WRITE_ZLP \
		CTL_CODE(FILE_DEVICE_UNKNOWN,	\
			 MCCIUSB_IOCTL_DEVSPEC_INDEX+0x1F, \
			 METHOD_BUFFERED,	\
			 FILE_ANY_ACCESS)


/****************************************************************************\
|
| MCCIUSB_IOCTL_GET_CURRENT_FRAME_NUMBER
|	Find the Current Frame ID
|
\****************************************************************************/
#define	MCCIUSB_IOCTL_GET_CURRENT_FRAME_NUMBER	\
		CTL_CODE(FILE_DEVICE_UNKNOWN,	\
			 MCCIUSB_IOCTL_INDEX+0x20, \
			 METHOD_BUFFERED,	\
			 FILE_ANY_ACCESS)

/****************************************************************************\
|
| MCCIUSB_IOCTL_SS_ENABLE
|	Enable and disable selective suspend
|
\****************************************************************************/
#define	MCCIUSB_IOCTL_SS_ENABLE	\
		CTL_CODE(FILE_DEVICE_UNKNOWN,	\
			 MCCIUSB_IOCTL_INDEX+0x21, \
			 METHOD_BUFFERED,	\
			 FILE_ANY_ACCESS)

#define	MCCIUSB_IOCTL_SS_DISABLE	\
		CTL_CODE(FILE_DEVICE_UNKNOWN,	\
			 MCCIUSB_IOCTL_INDEX+0x22, \
			 METHOD_BUFFERED,	\
			 FILE_ANY_ACCESS)


/****************************************************************************\
|
| MCCIUSB_IOCTL_REMOTE_WAKEUP_ENABLE and MCCIUSB_IOCTL_REMOTE_WAKEUP_DISABLE
|	Enable and disable Remote Wakeup
|
\****************************************************************************/
#define	MCCIUSB_IOCTL_REMOTE_WAKEUP_ENABLE	\
		CTL_CODE(FILE_DEVICE_UNKNOWN,	\
			 MCCIUSB_IOCTL_INDEX+0x23, \
			 METHOD_BUFFERED,	\
			 FILE_ANY_ACCESS)

#define	MCCIUSB_IOCTL_REMOTE_WAKEUP_DISABLE	\
		CTL_CODE(FILE_DEVICE_UNKNOWN,	\
			 MCCIUSB_IOCTL_INDEX+0x24, \
			 METHOD_BUFFERED,	\
			 FILE_ANY_ACCESS)

/*

IOCTL:	MCCIUSB_IOCTL_GET_FULL_DEVICE_INFO

Index:	Type:	MCCIUSB_GET_FULL_DEVICE_INFO

Function:
	Return new style interface info.

Input:
	A buffer to be filled.

Output:
	A more-or-less complete description of the device at its current
	speed is written to the buffer, as an MCCIUSB_DEVICE_INFORMATION_EX,
	followed by one or more (variable-length) 
	MCCIUSB_CONFIGURATION_INFORMATION_EX, structures, each with a 
	collection of (variable-length) MCCIUSB_INTERFACE_INFORMATION_EX
	structures, each with a (variable-length) array of
	MCCIUSB_ALTERNATE_SETTING_EX structures, each with a (variable-
	length)	array of MCCIUSB_PIPE_INFORMATION_EX entries).

Description:
	This API is used for information about the possible settings of the
	interfaces and pipes within a given configuration. It scans the
	device tree and builds an equivalent set of information about the
	device.

Returns:
	Number of bytes written.

*/

			 
#define	MCCIUSB_IOCTL_GET_FULL_DEVICE_INFO	\
		CTL_CODE(FILE_DEVICE_UNKNOWN,	\
			 MCCIUSB_IOCTL_INDEX+0x25, \
			 METHOD_BUFFERED,	\
			 FILE_ANY_ACCESS)

#include <pshpack4.h>

#pragma warning(push)
#pragma warning(disable: 4201)	/* 
				|| "non-standard extension" because of
				|| anonymous structure. Notationally very
				|| convenient
				*/

typedef struct _MCCIUSB_PIPE_INFORMATION_EX
	{
	/* 
	|| Maximum packet size for this pipe -- it's ULONG so we can
	|| cater to USB 3.1 Gen2 with the same API.
	*/
	ULONG		MaximumPacketSize;

	/* the base wMaxPacketSize for this pipe */
	USHORT		wBasePacketSize;

	/* the raw bmAttributes */
	UINT8		bmAttributes;

	/*
	|| bMaxBurst is burst size - 1; it's set from the high-bits of
	|| a high-speed max packet size, or from the burst of the ss ep
	|| companion descriptor.
	*/
	UINT8		bMaxBurst;

	/*
	|| These are the attributes from the ss ep companion; or zero.
	*/
	UINT8		bmCompanionAttributes;

	/*
	|| 8 bit USB endpoint address (includes direction)
	*/
	UCHAR		EndpointAddress;
	
	/* 
	|| taken from endpoint descriptor
	|| Polling interval in ms if interrupt pipe
	*/
	UCHAR		Interval;

	/*
	|| PipeType identifies type of transfer valid for this pipe
	*/
	USBD_PIPE_TYPE PipeType; 
	} MCCIUSB_PIPE_INFORMATION_EX, 
	*PMCCIUSB_PIPE_INFORMATION_EX;

typedef struct _MCCIUSB_ALTERNATE_SETTING_INFORMATION_HDR
	{
	/*
	|| Length of this structure, including
	|| all pipe information structures that
        || follow.
        */
	USHORT Length;       

	/* repeated for convenience */	
	UCHAR InterfaceNumber;
	UCHAR AlternateSetting;

	UCHAR Class;
	UCHAR SubClass;
	UCHAR Protocol;
	UCHAR iInterface;	/* string index */

	ULONG NumberOfPipes;
	} MCCIUSB_ALTERNATE_SETTING_INFORMATION_HDR;

typedef struct _MCCIUSB_ALTERNATE_SETTING_INFORMATION_EX
	{
	MCCIUSB_ALTERNATE_SETTING_INFORMATION_HDR;

	/* an array of pipes follow */
	MCCIUSB_PIPE_INFORMATION_EX Pipes[1];
	} MCCIUSB_ALTERNATE_SETTING_INFORMATION_EX, 
	*PMCCIUSB_ALTERNATE_SETTING_INFORMATION_EX;

typedef struct _MCCIUSB_INTERFACE_INFORMATION_HDR
	{
	/*
	|| Length of this structure, including
	|| all pipe information structures that
        || follow.
        */
	USHORT Length;       
	
	UCHAR InterfaceNumber;
	UCHAR NumberOfAlternateSettings;
	} MCCIUSB_INTERFACE_INFORMATION_HDR;

typedef struct _MCCIUSB_INTERFACE_INFORMATION_EX
	{
	MCCIUSB_INTERFACE_INFORMATION_HDR;

	/* an array of pipes follow */
	MCCIUSB_ALTERNATE_SETTING_INFORMATION_EX AlternateSettings[1];
	} MCCIUSB_INTERFACE_INFORMATION_EX, 
	*PMCCIUSB_INTERFACE_INFORMATION_EX;

typedef struct _MCCIUSB_CONFIGURATION_INFORMATION_HDR
	{
	/*
	|| Length of this structure, including
	|| all interface and pipe information structures that
        || follow.
        */
	USHORT Length;
	
	UCHAR iConfiguration;
	UCHAR bConfigurationValue;
	UCHAR bmAttributes;
	UCHAR MaxPower;

	UINT8 bReserved;
	UCHAR NumberOfInterfaces;

	} MCCIUSB_CONFIGURATION_INFORMATION_HDR;

typedef struct _MCCIUSB_CONFIGURATION_INFORMATION_EX
	{
	MCCIUSB_CONFIGURATION_INFORMATION_HDR;

	/* an array of interfaces follows */
	MCCIUSB_INTERFACE_INFORMATION_EX Interfaces[1];
	} MCCIUSB_CONFIGURATION_INFORMATION_EX, 
	*PMCCIUSB_CONFIGURATION_INFORMATION_EX;

typedef struct _MCCIUSB_DEVICE_INFORMATION_HDR
	{
	UINT32	Length;
	UINT32	MaxPacketSize0;
	UINT16	bcdUSB;
	UINT16	idVendor;
	UINT16	idProduct;
	UINT16	bcdDevice;

	UINT8	bDeviceClass;
	UINT8	bDeviceSubClass;
	UINT8	bDeviceProtocol;
	UINT8	bRawMaxPacketSize0;

	UINT8	iManufacturer;
	UINT8	iProduct;
	UINT8	iSerialNumber;
	UINT8	bNumConfigurations;
	} MCCIUSB_DEVICE_INFORMATION_HDR;

typedef struct _MCCIUSB_DEVICE_INFORMATION_EX
	{
	MCCIUSB_DEVICE_INFORMATION_HDR;

	MCCIUSB_CONFIGURATION_INFORMATION_EX Configurations[1];
	} MCCIUSB_DEVICE_INFORMATION_EX,
	*PMCCIUSB_DEVICE_INFORMATION_EX;

#pragma warning(pop)

#include <poppack.h>

/**** add new IOCTL codes here! ****/

/**** define the names from the older version of the driver ****/
#if __MCCIUSB_OLD_NAMES
# define GET_NUM_DEVICES	MCCIUSB_GET_NUM_DEVICES_IOCTL
# define GET_DEVICE_INFO	MCCIUSB_GET_DEVICE_INFO_IOCTL
# define GET_DEVICE_DESCRIPTOR	MCCIUSB_GET_DEVICE_DESCRIPTOR_IOCTL
# define GET_CONFIG_DESCRIPTOR	MCCIUSB_GET_CONFIG_DESCRIPTOR_IOCTL
# define GET_VERSION		MCCIUSB_GET_USBD_VERSION_IOCTL
# define GET_INTERFACE_INFO	MCCIUSB_GET_INTERFACE_INFO_IOCTL
# define SEND_USB_CONTROL	MCCIUSB_SEND_USB_CONTROL_IOCTL
# define GET_USB_CONTROL	MCCIUSB_GET_USB_CONTROL_IOCTL

#endif /* __MCCIUSB_OLD_NAMES */

/**** use this for driver-specific codes ****/
#define	MCCIUSB_IOCTL_DEVSPEC_INDEX	(MCCIUSB_IOCTL_INDEX+0x100)

#if defined(_WIN64)
#include <pshpack4.h>
#endif

typedef struct _MCCI_USBD_PIPE_INFORMATION_32
	{
	/*
	|| These fields are filled in by USBD
	*/
	/* 
	|| Maximum packet size for this pipe
	*/
	USHORT		MaximumPacketSize;
	/*
	|| 8 bit USB endpoint address (includes direction)
	*/
	UCHAR		EndpointAddress;     
	
	/* 
	|| taken from endpoint descriptor
	|| Polling interval in ms if interrupt pipe
	*/
	UCHAR		Interval;

	/*
	|| PipeType identifies type of transfer valid for this pipe
	*/
	USBD_PIPE_TYPE PipeType; 
	VOID * POINTER_32 PipeHandle;

	/*
	|| INPUT
	|| These fields are filled in by the client driver
	|| Maximum size for a single request in bytes.
	*/
	ULONG MaximumTransferSize;
		       
	ULONG PipeFlags;
	} MCCI_USBD_PIPE_INFORMATION_32, *PMCCI_USBD_PIPE_INFORMATION_32;


typedef struct MCCI_USBD_INTERFACE_INFORMATION_32
	{
	/*
	|| Length of this structure, including
	|| all pipe information structures that
        || follow.
        */
	USHORT Length;       
	
	/*
	||INPUT
	|| 
	|| Interface number and Alternate setting this
	|| structure is associated with
	*/
	UCHAR InterfaceNumber;
	UCHAR AlternateSetting;

	
	/* 
	|| OUTPUT
	|| These fields are filled in by USBD
	*/
	UCHAR Class;
	UCHAR SubClass;
	UCHAR Protocol;
	UCHAR Reserved;

	VOID * POINTER_32 InterfaceHandle;
	ULONG NumberOfPipes;
	
	/*
	|| INPUT/OUPUT
	|| see PIPE_INFORMATION
	*/

	MCCI_USBD_PIPE_INFORMATION_32 Pipes[1];
	} MCCI_USBD_INTERFACE_INFORMATION_32, *PMCCI_USBD_INTERFACE_INFORMATION_32;

/*
|| In case of 64 bit build, we need to have 4 bytes packed interface info structure
|| to support the w32 application executing on 64 bit driver
*/
#if defined(_WIN64)
#include <poppack.h>
#endif

/*
|| Macro to identify the executing build version (32 or 64 bit)
*/
#if defined(_WIN64)
#define MCCIUSB_IS_WIN32APP_ON_WIN64DRV(pIrp) IoIs32bitProcess(pIrp)
#else 
#define MCCIUSB_IS_WIN32APP_ON_WIN64DRV(pIrp) FALSE
#endif

#define	MCCIUSB_DEBUG_DISPLAY_IFCINFO(pDE,pOpIfcInfo)				\
	do	{ 								\
		MCCIUSB_Printf(pDE, DBGLVL_FLOW,				\
			("Length 0x%x\n",(pOpIfcInfo)->Length));		\
		MCCIUSB_Printf(pDE, DBGLVL_FLOW,				\
			("InterfaceNumber 0x%x\n",(pOpIfcInfo)->InterfaceNumber));	\
		MCCIUSB_Printf(pDE, DBGLVL_FLOW,				\
			("AlternateSetting 0x%x\n", (pOpIfcInfo)->AlternateSetting));	\
		MCCIUSB_Printf(pDE, DBGLVL_FLOW,				\
			("Class 0x%x\n",(pOpIfcInfo)->Class));			\
		MCCIUSB_Printf(pDE, DBGLVL_FLOW,				\
			("SubClass 0x%x\n",(pOpIfcInfo)->SubClass));		\
		MCCIUSB_Printf(pDE, DBGLVL_FLOW,				\
			("Protocol 0x%x\n",(pOpIfcInfo)->Protocol));		\
		MCCIUSB_Printf(pDE, DBGLVL_FLOW,				\
			("Reserved 0x%x\n", (pOpIfcInfo)->Reserved));		\
		MCCIUSB_Printf(pDE, DBGLVL_FLOW,				\
			("InterfaceHandle 0x%x\n",(pOpIfcInfo)->InterfaceHandle));	\
		MCCIUSB_Printf(pDE, DBGLVL_FLOW,					\
			("NumberOfPipes 0x%x\n", (pOpIfcInfo)->NumberOfPipes));		\
		} while (0)

/*
|| Copies the 64 bit USBD_INTERFACE_INFORMATION structure to 32 bit 
|| MCCI_USBD_INTERFACE_INFORMATION_32
*/
#define	MCCIUSB_IOCTL_CPY_IFCINFO_W64TOW32(pOutBuffer, pIfcInfo) \
	do	{ \
		PMCCI_USBD_INTERFACE_INFORMATION_32	__pOpIfcInfo;				\
		__pOpIfcInfo = (PMCCI_USBD_INTERFACE_INFORMATION_32) (pOutBuffer);		\
		RtlZeroMemory(__pOpIfcInfo, sizeof(MCCI_USBD_INTERFACE_INFORMATION_32));	\
		(__pOpIfcInfo)->Length		 = (USHORT)(offsetof(MCCI_USBD_INTERFACE_INFORMATION_32,\
									Pipes[0]) 			 \
									+ (pIfcInfo)->NumberOfPipes *	\
								     sizeof(MCCI_USBD_PIPE_INFORMATION_32));\
		(__pOpIfcInfo)->InterfaceNumber	 = (pIfcInfo)->InterfaceNumber;		\
		(__pOpIfcInfo)->AlternateSetting = (pIfcInfo)->AlternateSetting;	\
		(__pOpIfcInfo)->Class		 = (pIfcInfo)->Class;			\
		(__pOpIfcInfo)->SubClass	 = (pIfcInfo)->SubClass;		\
		(__pOpIfcInfo)->Protocol 	 = (pIfcInfo)->Protocol;		\
		(__pOpIfcInfo)->Reserved	 =  (pIfcInfo)->Reserved;		\
		(__pOpIfcInfo)->InterfaceHandle	 = NULL;				\
		(__pOpIfcInfo)->NumberOfPipes	 =  (pIfcInfo)->NumberOfPipes;		\
		} while (0)

#define	MCCIUSB_DEBUG_DISPLAY_PIPEINFO(pDE, pOpPipeInfo) 				\
	do	{									\
		MCCIUSB_Printf(pDE, DBGLVL_FLOW,					\
			("MaximumPacketSize 0x%x\n", (pOpPipeInfo)->MaximumPacketSize));\
		MCCIUSB_Printf(pDE, DBGLVL_FLOW,					\
			("EndpointAddress 0x%x\n", (pOpPipeInfo)->EndpointAddress));	\
		MCCIUSB_Printf(pDE, DBGLVL_FLOW,					\
			("Interval 0x%x\n",(pOpPipeInfo)->Interval));			\
		MCCIUSB_Printf(pDE, DBGLVL_FLOW,					\
			("PipeType 0x%x\n",(pOpPipeInfo)->PipeType));			\
		MCCIUSB_Printf(pDE, DBGLVL_FLOW,					\
			("PipeHandle 0x%x\n",(pOpPipeInfo)->PipeHandle));		\
		MCCIUSB_Printf(pDE, DBGLVL_FLOW,					\
			("MaximumTransferSize 0x%x\n",(pOpPipeInfo)->MaximumTransferSize));\
		MCCIUSB_Printf(pDE, DBGLVL_FLOW,					\
			("PipeFlags 0x%x\n",(pOpPipeInfo)->PipeFlags));			\
		} while (0)

/*
|| Copies the 64 bit USBD_PIPE_INFORMATION structure to 32 bit 
|| PMCCI_USBD_PIPE_INFORMATION_32
*/
#define	MCCIUSB_IOCTL_CPY_PIPEINFO_W64TOW32(pOutBuffer, pPipeInfo) \
	do	{ \
		PMCCI_USBD_PIPE_INFORMATION_32	__pOpPipeInfo;				\
		__pOpPipeInfo = (PMCCI_USBD_PIPE_INFORMATION_32) (pOutBuffer);		\
		RtlZeroMemory(__pOpPipeInfo, sizeof(MCCI_USBD_PIPE_INFORMATION_32));	\
		(__pOpPipeInfo)->MaximumPacketSize = (pPipeInfo)->MaximumPacketSize;	\
		(__pOpPipeInfo)->EndpointAddress   = (pPipeInfo)->EndpointAddress;	\
		(__pOpPipeInfo)->Interval	  = (pPipeInfo)->Interval;		\
		(__pOpPipeInfo)->PipeType	  = (pPipeInfo)->PipeType;		\
		(__pOpPipeInfo)->PipeHandle	 = NULL;				\
		(__pOpPipeInfo)->MaximumTransferSize = (pPipeInfo)->MaximumTransferSize;\
		(__pOpPipeInfo)->PipeFlags	=  (pPipeInfo)->PipeFlags;		\
		} while (0)

#define	MCCIUSB_DEBUG_DISPLAY_CONFIGURATION_DESCRIPTOR(pDE,pOpCfgDesc)			\
	do	{									\
		USB_CONFIGURATION_DESCRIPTOR	*__pConfigDesc;				\
		__pConfigDesc = (USB_CONFIGURATION_DESCRIPTOR*)(pOpCfgDesc);		\
		MCCIUSB_Printf(pDE, DBGLVL_FLOW,					\
			("bLength            :0x%02x\n", (__pConfigDesc)->bLength));	\
		MCCIUSB_Printf(pDE, DBGLVL_FLOW,					\
			("bDescriptorType    :0x%02x\n", (__pConfigDesc)->bDescriptorType));\
		MCCIUSB_Printf(pDE, DBGLVL_FLOW,					\
			("wTotalLength       :0x%04x\n",(__pConfigDesc)->wTotalLength));\
		MCCIUSB_Printf(pDE, DBGLVL_FLOW,					\
			("bNumInterfaces     :0x%02x\n",(__pConfigDesc)->bNumInterfaces));\
		MCCIUSB_Printf(pDE, DBGLVL_FLOW,					\
			("bConfigurationValue:0x%02x\n",(__pConfigDesc)->bConfigurationValue));\
		MCCIUSB_Printf(pDE, DBGLVL_FLOW,					\
			("iConfiguration     :0x%02x\n",(__pConfigDesc)->iConfiguration));\
		MCCIUSB_Printf(pDE, DBGLVL_FLOW,					\
			("bmAttributes       :0x%02x\n",(__pConfigDesc)->bmAttributes));\
		MCCIUSB_Printf(pDE, DBGLVL_FLOW,					\
			("MaxPower           :0x%02x\n",(__pConfigDesc)->MaxPower));	\
		}while (0)

#define	MCCIUSB_DEBUG_DISPLAY_INTERFACE_DESCRIPTOR(pDE,pOpIfcDesc)			\
	do	{									\
		USB_INTERFACE_DESCRIPTOR	*__pIfcDesc;				\
		__pIfcDesc = (USB_INTERFACE_DESCRIPTOR*)(pOpIfcDesc);			\
		MCCIUSB_Printf(pDE, DBGLVL_FLOW,					\
			("bLength           :0x%02x\n", (__pIfcDesc)->bLength));	\
		MCCIUSB_Printf(pDE, DBGLVL_FLOW,					\
			("bDescriptorType   :0x%02x\n", (__pIfcDesc)->bDescriptorType));\
		MCCIUSB_Printf(pDE, DBGLVL_FLOW,					\
			("bInterfaceNumber  :0x%02x\n",(__pIfcDesc)->bInterfaceNumber));\
		MCCIUSB_Printf(pDE, DBGLVL_FLOW,					\
			("bAlternateSetting : 0x%02x\n",(__pIfcDesc)->bAlternateSetting));\
		MCCIUSB_Printf(pDE, DBGLVL_FLOW,					\
			("bNumEndpoints     :0x%02x\n",(__pIfcDesc)->bNumEndpoints));	\
		MCCIUSB_Printf(pDE, DBGLVL_FLOW,					\
			("bInterfaceClass   :0x%02x\n",(__pIfcDesc)->bInterfaceClass));	\
		MCCIUSB_Printf(pDE, DBGLVL_FLOW,					\
			("bInterfaceSubClass: 0x%02x\n",(__pIfcDesc)->bInterfaceSubClass));\
		MCCIUSB_Printf(pDE, DBGLVL_FLOW,					\
			("bInterfaceProtocol:0x%02x\n",(__pIfcDesc)->bInterfaceProtocol));\
		MCCIUSB_Printf(pDE, DBGLVL_FLOW,					\
			("iInterface        :0x%02x\n",(__pIfcDesc)->iInterface));	\
		}while (0)


#define	MCCIUSB_DEBUG_DISPLAY_ENDPOINT_DESCRIPTOR(pDE,pOpEpDec)				\
	do	{									\
		USB_ENDPOINT_DESCRIPTOR		*__pEPDesc;				\
		__pEPDesc = (USB_ENDPOINT_DESCRIPTOR *)pOpEpDec;			\
		MCCIUSB_Printf(pDE, DBGLVL_FLOW,					\
			("bLength         :0x%02x\n", (__pEPDesc)->bLength));		\
		MCCIUSB_Printf(pDE, DBGLVL_FLOW,					\
			("bDescriptorType :0x%02x\n", (__pEPDesc)->bDescriptorType));	\
		MCCIUSB_Printf(pDE, DBGLVL_FLOW,					\
			("bEndpointAddress:0x%02x\n",(__pEPDesc)->bEndpointAddress));	\
		MCCIUSB_Printf(pDE, DBGLVL_FLOW,					\
			("bmAttributes    :0x%02x\n",(__pEPDesc)->bmAttributes));	\
		MCCIUSB_Printf(pDE, DBGLVL_FLOW,					\
			("wMaxPacketSize  :0x%04x\n",(__pEPDesc)->wMaxPacketSize));	\
		MCCIUSB_Printf(pDE, DBGLVL_FLOW,					\
			("bInterval       :0x%02x\n",(__pEPDesc)->bInterval));		\
		} while (0)

/**** end of mcciusb.h ****/
#endif /* _MCCIUSB_H_ */
