// getopt() for Windows

#include <stdlib.h>
#include <string.h>
#include <getopt.h>

char *optarg = NULL;
int optind = 0, optopt = 0;

int getopt(int argc, char *argv[], const char *optstring) {
	static char *next = NULL;

	if(optind == 0)
		next = NULL;
	optarg = NULL;
	if((next == NULL) || (*next == 0)) {
		if(optind == 0)
			optind++;
		if((optind >= argc) || (argv[optind][0] != '-') || (argv[optind][1] == 0)) {
			optarg = NULL;
			if(optind < argc)
				optarg = argv[optind];
			return -1;
		}
		next = argv[optind];
		next++;
		optind++;
	}
	char c = *next++;
	if(c == ':')
		return '?';
	char *p = strchr(optstring, c);
	if(p == NULL)
		return '?';
	p++;
	if(*p == ':') {
		if(*next != 0) {
			optarg = next;
			next = NULL;
		} else if(optind < argc) {
			optarg = argv[optind];
			optind++;
		} else
			return '?';
	}
	return c;
}
