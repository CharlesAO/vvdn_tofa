
#ifndef _HIGHRESTIME_H
#define _HIGHRESTIME_H

typedef LARGE_INTEGER highres_time_t;

static __inline void highres_gettime(highres_time_t *ptr) {
	QueryPerformanceCounter(ptr);
}

static __inline double highres_elapsed_ms(highres_time_t *start, const highres_time_t *end) {
	static LARGE_INTEGER perfFrequency;
	static int havePerfFrequency = 0;
	if(!havePerfFrequency) {
		QueryPerformanceFrequency(&perfFrequency);
		havePerfFrequency = 1;
	}
	return (end->QuadPart - start->QuadPart) * 1000.0 / perfFrequency.QuadPart;
}

#endif//_HIGHRESTIME_H

