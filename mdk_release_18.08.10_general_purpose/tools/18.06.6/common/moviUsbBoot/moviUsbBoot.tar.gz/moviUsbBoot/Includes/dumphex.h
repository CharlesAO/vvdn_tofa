
#ifndef _DUMPHEX_H
#define _DUMPHEX_H

#include <stdio.h>
#include <stdlib.h>

extern void dumphex(FILE *outf, const void *buff, size_t sz);

#endif//_DUMPHEX_H
