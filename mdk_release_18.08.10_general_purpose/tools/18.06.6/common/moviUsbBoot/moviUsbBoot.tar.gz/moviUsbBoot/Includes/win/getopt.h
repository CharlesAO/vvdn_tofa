// getopt() for Windows

#ifndef _GETOPT_H
#define _GETOPT_H

extern char *optarg;
extern int optind, optopt;

extern int getopt(int argc, char *argv[], const char *optstring);

#endif//_GETOPT_H
