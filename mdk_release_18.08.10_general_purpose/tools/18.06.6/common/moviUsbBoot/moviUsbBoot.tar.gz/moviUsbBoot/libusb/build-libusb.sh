#!/bin/sh
PREFIX=$(cd $(dirname $0); pwd)
BASEDIR=$(dirname $PREFIX)
BINUTILSDIR=$(cd $BASEDIR/binutils-2.26-centos5/bin && pwd)
GCCDIR=$(cd $BASEDIR/gcc-5.3.0-centos5/bin && pwd)
PATH="$BINUTILSDIR:$GCCDIR:$PATH"
cd $BASEDIR/libusb-1.0.20 || exit $?
make -i clean distclean
./configure \
    --prefix=$PREFIX \
    --disable-udev \
    CFLAGS=-O3 \
    || exit $?

make || exit $?
make install || exit $?
